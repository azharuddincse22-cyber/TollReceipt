# Toll Receipt Bluetooth Printer App

This is a WebView-based Android Studio project based on the supplied Toll Receipt App APK.

## Bluetooth printer workflow
1. Install/build the app.
2. Pair the Rongta Bluetooth printer in Android Bluetooth settings.
3. Open the app and tap **Connect Bluetooth Printer**.
4. Select the paired printer.
5. Fill the receipt and tap **Generate Receipt**.
6. The app sends the receipt directly to the Bluetooth thermal printer using ESC/POS.

## Important
- This implementation uses classic Bluetooth SPP UUID `00001101-0000-1000-8000-00805F9B34FB`, which is common for Rongta/ESC-POS printers.
- The printer must be paired with Android before connecting from the app.
- `window.print()` is no longer used inside the Android app.
- The printer's paper width is assumed to be 58/80mm compatible ESC/POS. The current text is formatted for a typical 58mm printer.
- If your specific printer does not cut paper automatically, remove or change the ESC/POS cut command in `MainActivity.java`.
