package com.example.tollreceiptapp;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQUEST_BT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView webView;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private BluetoothDevice connectedDevice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        webView = findViewById(R.id.webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        webView.loadUrl("file:///android_asset/index.html");

        requestBluetoothPermissions();
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            List<String> permissions = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT);
            }
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN);
            }
            if (!permissions.isEmpty()) {
                requestPermissions(permissions.toArray(new String[0]), REQUEST_BT);
            }
        }
    }

    private boolean hasBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void openBluetoothSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void showPairedPrinters() {
        if (bluetoothAdapter == null) {
            toast("This device does not support Bluetooth");
            return;
        }
        if (!hasBluetoothPermission()) {
            requestBluetoothPermissions();
            return;
        }
        if (!bluetoothAdapter.isEnabled()) {
            new AlertDialog.Builder(this)
                    .setTitle("Bluetooth is OFF")
                    .setMessage("Turn Bluetooth ON to connect the receipt printer.")
                    .setPositiveButton("Bluetooth Settings", (d, w) -> openBluetoothSettings())
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }

        Set<BluetoothDevice> paired = bluetoothAdapter.getBondedDevices();
        if (paired == null || paired.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("No paired printer")
                    .setMessage("First pair the Rongta printer in Android Bluetooth settings, then return here and tap Connect Printer.")
                    .setPositiveButton("Bluetooth Settings", (d, w) -> openBluetoothSettings())
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }

        final List<BluetoothDevice> devices = new ArrayList<>(paired);
        String[] names = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String name;
            try { name = d.getName(); } catch (SecurityException e) { name = "Bluetooth device"; }
            if (name == null || name.trim().isEmpty()) name = "Unknown device";
            names[i] = name + "\n" + d.getAddress();
        }

        new AlertDialog.Builder(this)
                .setTitle("Select Bluetooth printer")
                .setItems(names, (dialog, which) -> connectToPrinter(devices.get(which)))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void connectToPrinter(BluetoothDevice device) {
        new Thread(() -> {
            try {
                closeConnection();
                if (bluetoothAdapter != null) bluetoothAdapter.cancelDiscovery();
                BluetoothSocket newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                newSocket.connect();
                OutputStream out = newSocket.getOutputStream();
                socket = newSocket;
                outputStream = out;
                connectedDevice = device;

                String name = "Printer";
                if (hasBluetoothPermission()) {
                    try { if (device.getName() != null) name = device.getName(); } catch (SecurityException ignored) {}
                }
                final String finalName = name;
                runOnUiThread(() -> {
                    toast("Connected: " + finalName);
                    callJs("window.onPrinterConnected(" + JSONObject.quote(finalName) + ")");
                });
            } catch (Exception e) {
                closeConnection();
                runOnUiThread(() -> {
                    toast("Printer connection failed: " + e.getMessage());
                    callJs("window.onPrinterError(" + JSONObject.quote("Connection failed: " + e.getMessage()) + ")");
                });
            }
        }).start();
    }

    private void printReceipt(final JSONObject data) {
        new Thread(() -> {
            try {
                if (outputStream == null || socket == null || !socket.isConnected()) {
                    runOnUiThread(() -> {
                        toast("Connect the Bluetooth printer first");
                        showPairedPrinters();
                    });
                    return;
                }

                String ticket = data.optString("ticket");
                String booth = data.optString("booth");
                String date = data.optString("date");
                String vehicle = data.optString("vehicle");
                String vehicleType = data.optString("vehicleType");
                String journey = data.optString("journey");
                String fee = data.optString("fee");
                String stdWeight = data.optString("stdWeight");
                String actWeight = data.optString("actWeight");

                byte[] receipt = buildEscPosReceipt(ticket, booth, date, vehicle, vehicleType, journey, fee, stdWeight, actWeight);
                outputStream.write(receipt);
                outputStream.flush();

                runOnUiThread(() -> {
                    toast("Receipt printed");
                    callJs("window.onPrintSuccess()");
                });
            } catch (Exception e) {
                closeConnection();
                runOnUiThread(() -> {
                    toast("Printing failed: " + e.getMessage());
                    callJs("window.onPrinterError(" + JSONObject.quote("Printing failed: " + e.getMessage()) + ")");
                });
            }
        }).start();
    }

    private byte[] buildEscPosReceipt(String ticket, String booth, String date, String vehicle,
                                      String vehicleType, String journey, String fee,
                                      String stdWeight, String actWeight) {
        StringBuilder s = new StringBuilder();
        s.append("\u001B\u0040");                 // initialize
        s.append("\u001B\u0061\u0001");         // center
        s.append("National Highway Authority of India\n");
        s.append("Mayoguri Changrabandha to Jargaon I\n");
        s.append("Km 74.900 - NH-AH-48 West Bengal\n");
        s.append("Rangalibajna Toll Plaza\n");
        s.append("--------------------------------\n");
        s.append("\u001B\u0061\u0000");         // left
        s.append("Ticket No: ").append(ticket).append("\n");
        s.append("Booth & Oper. No: ").append(booth).append("\n");
        s.append("Date & Time: ").append(date).append("\n");
        s.append("Vehicle No: ").append(vehicle).append("\n");
        s.append("Vehicle Type: ").append(vehicleType).append("\n");
        s.append("Type of Journey: ").append(journey).append("\n");
        s.append("Fee: Rs. ").append(fee).append("\n");
        s.append("--------------------------------\n");
        s.append("Only for Overload Vehicles:\n");
        s.append("Standard Weight: ").append(stdWeight).append(" Kg\n");
        s.append("Actual Weight: ").append(actWeight).append(" Kg\n\n");
        s.append("All toll payments via FASTag only\n");
        s.append("Double of Fee to be paid if\n");
        s.append("Non FASTag vehicle enters in FASTag lane\n");
        s.append("24x7 help Line 1033\n");
        s.append("Wish You Safe & Happy Journey\n\n\n");
        s.append("\u001D\u0056\u0000");         // full cut (if supported)
        return s.toString().getBytes(Charset.forName("CP437"));
    }

    private void closeConnection() {
        try { if (outputStream != null) outputStream.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        outputStream = null;
        socket = null;
        connectedDevice = null;
    }

    private void callJs(String javascript) {
        if (webView != null) webView.evaluateJavascript(javascript, null);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        closeConnection();
        if (webView != null) webView.removeJavascriptInterface("AndroidPrinter");
        super.onDestroy();
    }

    public class PrinterBridge {
        @JavascriptInterface
        public void connectPrinter() {
            runOnUiThread(() -> showPairedPrinters());
        }

        @JavascriptInterface
        public void printReceipt(String json) {
            try {
                JSONObject data = new JSONObject(json);
                printReceipt(data);
            } catch (Exception e) {
                runOnUiThread(() -> toast("Invalid receipt data"));
            }
        }

        @JavascriptInterface
        public boolean isPrinterConnected() {
            return socket != null && socket.isConnected() && outputStream != null;
        }

        @JavascriptInterface
        public void openBluetoothSettings() {
            runOnUiThread(() -> MainActivity.this.openBluetoothSettings());
        }
    }
}
