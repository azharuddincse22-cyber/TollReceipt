# Build this Android project on your phone

This project includes a GitHub Actions workflow at:

`.github/workflows/build-apk.yml`

## Steps

1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project to the repository.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK**.
6. Tap **Run workflow**.
7. Wait for the build to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download `TollReceipt-debug-APK`.
10. Extract the downloaded ZIP and install the APK on your Android phone.

The workflow uses Java 17, Gradle 8.7 and Android SDK 35.
